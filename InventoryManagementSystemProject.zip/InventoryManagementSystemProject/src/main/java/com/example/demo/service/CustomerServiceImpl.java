package com.example.demo.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Customer;
import com.example.demo.error.CustomerNotFoundException;
import com.example.demo.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {
@Autowired
	CustomerRepository  customerrepo;

@Override
public List<Customer> fetchCustomerList() {
	// TODO Auto-generated method stub
	return customerrepo.findAll();
}

@Override
public Customer fetchCustomerById(Integer cid) throws CustomerNotFoundException {
	// TODO Auto-generated method stub
	Optional<Customer> customer1= customerrepo.findById(cid);
	if(!customer1.isPresent())
	{
		throw new CustomerNotFoundException("Customer id not exists");
	}
	return customerrepo.findById(cid).get();
}

@Override
public void deleteCustomerById(Integer cid)throws CustomerNotFoundException {
	// TODO Auto-generated method stub
	Optional<Customer> customer1= customerrepo.findById(cid);
	if(!customer1.isPresent())
	{
		throw new CustomerNotFoundException("Customer id not exists");
	}
	customerrepo.deleteById(cid);
}

@Override
public Customer updateCustomerById(Integer cid, Customer customer)throws CustomerNotFoundException {
	// TODO Auto-generated method stub
	Optional<Customer> customer1= customerrepo.findById( cid);
	Customer custdb=null;
				if(customer1.isPresent()) {
					custdb=	customerrepo.findById( cid).get();
					if(Objects.nonNull(customer.getCustomerName()) && !"".equalsIgnoreCase(customer.getCustomerName())) {
						custdb.setCustomerName(customer.getCustomerName());

					}
					if(Objects.nonNull(customer.getCustomerMobileNo()) && !"".equals(customer.getCustomerMobileNo())) {
						custdb.setCustomerMobileNo(customer.getCustomerMobileNo());
						System.out.println(customer.getCustomerMobileNo());
					}
					if(Objects.nonNull(customer.getCustomerAddress()) && !"".equals(customer.getCustomerAddress())) {
						custdb.setCustomerAddress(customer.getCustomerAddress());
						System.out.println(customer.getCustomerAddress());
					}
					
				}
				else
				{
					throw new CustomerNotFoundException("Customer id not exists");
				}
					return customerrepo.save(custdb);

				
	}

}



