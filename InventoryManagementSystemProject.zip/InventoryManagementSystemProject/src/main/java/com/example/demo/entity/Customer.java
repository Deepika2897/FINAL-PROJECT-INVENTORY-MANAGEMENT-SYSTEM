package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

import javax.persistence.Id;

import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
//This annotation is used to convert the class into the tables.
@Entity
@Table(name="CustomerTable")
public class Customer {
	
	//This annotation is used to create the primary key. 
	@Id
	//This annotation is used to create the primary key value as auto generated one.
	@GeneratedValue
	@Column (name="Customer_ID")
   	private int customerId;
	//This annotation is used to check the message is blank or not if it is blank it will not allow. 
    @NotBlank(message="Customer name cannot be blank")
    @Column (name="Customer_Name")
	private String customerName;
  //This annotation is used to check the message length if we want only fixed digit values means then we can use it.
    @Length(min=10,max=13,message="Mobile number must be 10 digits")
    @NotBlank(message="Customer mobno cannot be blank")
    @Column (name="Customer_MobileNo")
	private String customerMobileNo;
  //This annotation also check the message is present or not.
    @NotBlank(message="Customer Address cannot be blank")
    @Length(min=3,message="Address atleast have 3 letters")
    @Column (name="Customer_Address")
	private String customerAddress;
    //constructor without arguments
	public Customer() {
		super();
	}
	
	//constructor with arguments
	
	public Customer(int customerId, @NotBlank(message = "Customer name cannot be blank") String customerName,
			@Length(min = 10, max = 13, message = "Mobile number must be 10 digits") @NotBlank(message = "Customer mobno cannot be blank") String customerMobileNo,
			@NotBlank(message = "Customer Address cannot be blank") @Length(min = 3, message = "Address atleast have 3 letters") String customerAddress) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerMobileNo = customerMobileNo;
		this.customerAddress = customerAddress;
	}
	
	//getter and setter methods
	public int getCustomerId() {
		return customerId;
	}
	
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerMobileNo() {
		return customerMobileNo;
	}
	public void setCustomerMobileNo(String customerMobileNo) {
		this.customerMobileNo = customerMobileNo;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	// ToString methods to display the output in the result screen
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerMobileNo="
				+ customerMobileNo + ", customerAddress=" + customerAddress + "]";
	}
    
	
}
