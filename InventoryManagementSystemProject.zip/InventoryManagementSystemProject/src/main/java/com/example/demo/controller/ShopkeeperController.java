package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.entity.Shopkeeper;
import com.example.demo.error.ProductNotFoundException;
import com.example.demo.service.ShopkeeperService;



@RestController
public class ShopkeeperController {
 @Autowired
	ShopkeeperService  shopkeeperservice;
 @PostMapping("/product/insertion/")
	public Shopkeeper addshopkeeper(@RequestBody Shopkeeper shopkeeper)

{
	return shopkeeperservice.addshopkeeper(shopkeeper);
}
 

 @GetMapping("/product/selectall/")
 public List<Shopkeeper>fetchProductList() 
 {
	 return shopkeeperservice.fetchProductList();
 }
	
 

@GetMapping("/product/selectbyid/{id}")
public Shopkeeper fetchProductById(@PathVariable("id") Integer pid) throws ProductNotFoundException
{
	return shopkeeperservice.fetchProductById(pid);
}
@GetMapping("/product/selectbyname/{pname}")
public Shopkeeper getProductByName(@PathVariable("pname") String pname)
{
	return shopkeeperservice.findByproductName(pname);
}
@GetMapping("/product/selectbytype/{ptype}")
public Shopkeeper getProductByType(@PathVariable("ptype") String ptype)
{
	return shopkeeperservice.findByproductType(ptype);
}
@GetMapping("/product/selectbybrand/{pbrand}")
public Shopkeeper getProductByBrand(@PathVariable("pbrand") String pbrand)
{
	return shopkeeperservice.findByproductBrand(pbrand);
}
@GetMapping("/product/selectbyquantity/{pquantity}")
public Shopkeeper getProductByQuantity(@PathVariable("pquantity") Integer pquantity)
{
	return shopkeeperservice.findByproductQuantity(pquantity);
}
@GetMapping("/product/selectbyprice/{pprice}")
public Shopkeeper getProductByPrice(@PathVariable("pprice") double pprice)
{
	return shopkeeperservice.findByproductPrice(pprice);
}


@PutMapping("/product/updatebyid/{id}")
public Shopkeeper updateProductById(@PathVariable("id")Integer pid,@RequestBody Shopkeeper shopkeeper) throws ProductNotFoundException
{
	return shopkeeperservice.updateProductById(pid,shopkeeper);
}
@DeleteMapping("/product/deletebyid/{id}")
public String  deleteProductById(@PathVariable("id") Integer pid) throws ProductNotFoundException
{
	shopkeeperservice.deleteProductById(pid);
	return "Product is deleted";
}
}











