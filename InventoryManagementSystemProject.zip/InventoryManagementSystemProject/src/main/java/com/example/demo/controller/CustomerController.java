package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Customer;
import com.example.demo.error.CustomerNotFoundException;
import com.example.demo.service.CustomerService;

@RestController
public class CustomerController {
@Autowired
	CustomerService customerservice;
@GetMapping("/customer/all/")
public List<Customer>fetchCustomerList() 
{
	 return customerservice.fetchCustomerList();
}
@GetMapping("/customer/byid/{id}")
public Customer fetchCustomerById(@PathVariable("id") Integer cid) throws CustomerNotFoundException
{
	return customerservice.fetchCustomerById(cid);
}
@DeleteMapping("/customer/deletebyid/{id}")
public String  deleteCustomerById(@PathVariable("id") Integer cid) throws CustomerNotFoundException
{
	customerservice.deleteCustomerById(cid);
	return "Product is deleted successfully";
}
@PutMapping("/customer/updatebyid/{id}")
public Customer updateCustomerById(@PathVariable("id")Integer cid,@RequestBody Customer customer) throws CustomerNotFoundException
{
	return customerservice.updateCustomerById(cid,customer);
}
}
