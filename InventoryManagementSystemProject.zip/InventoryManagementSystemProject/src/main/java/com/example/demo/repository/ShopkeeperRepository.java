 package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Shopkeeper;
@Repository
public interface ShopkeeperRepository extends JpaRepository<Shopkeeper, Integer>{

	Shopkeeper findByproductName(String pname);

	Shopkeeper findByProductType(String ptype);

	Shopkeeper findByProductBrand(String pbrand);

	Shopkeeper findByProductQuantity(Integer pquantity);

	Shopkeeper findByProductPrice(double pprice);

	

	

	

	

	
}
