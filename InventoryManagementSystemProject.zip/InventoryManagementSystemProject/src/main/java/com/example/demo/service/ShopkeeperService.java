package com.example.demo.service;

import java.util.List;


import com.example.demo.entity.Shopkeeper;
import com.example.demo.error.ProductNotFoundException;

public interface ShopkeeperService {

	Shopkeeper addshopkeeper(Shopkeeper shopkeeper);
	
	List<Shopkeeper> fetchProductList();

	Shopkeeper fetchProductById(Integer pid) throws ProductNotFoundException;
	
	Shopkeeper updateProductById(Integer pid, Shopkeeper shopkeeper)  throws ProductNotFoundException;
	
	void deleteProductById(Integer pid) throws ProductNotFoundException;
	
	Shopkeeper findByproductName(String pname);
	
	Shopkeeper findByproductType(String ptype);
	
	Shopkeeper findByproductBrand(String pbrand);
	
	Shopkeeper findByproductQuantity(Integer pquantity);
	
	Shopkeeper findByproductPrice(double pprice);







	

	 

}
