package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Customer;
import com.example.demo.error.CustomerNotFoundException;

public interface CustomerService {

	List<Customer> fetchCustomerList();

	Customer fetchCustomerById(Integer pid) throws CustomerNotFoundException;

	void deleteCustomerById(Integer cid)throws CustomerNotFoundException ;

	Customer updateCustomerById(Integer cid, Customer customer) throws CustomerNotFoundException;

}
