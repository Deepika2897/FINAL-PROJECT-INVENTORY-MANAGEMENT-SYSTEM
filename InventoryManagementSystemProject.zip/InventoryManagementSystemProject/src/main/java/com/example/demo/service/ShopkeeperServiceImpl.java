package com.example.demo.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.entity.Shopkeeper;
import com.example.demo.error.ProductNotFoundException;
import com.example.demo.repository.ShopkeeperRepository;

@Service
public class ShopkeeperServiceImpl implements ShopkeeperService {
@Autowired
	ShopkeeperRepository shopkeeperrepo;

@Override
public Shopkeeper addshopkeeper(Shopkeeper shopkeeper) {
	

	int soapStock=100;
    int pasteStock=80;
    int biscutsStock=200;
    int chocolateStock=100;
    int coolDrinksStock=200;
   
	if(shopkeeper.getProductName().equalsIgnoreCase("Lux") && soapStock>shopkeeper.getProductQuantity())
	{
		shopkeeper.currentStock=soapStock-shopkeeper.getProductQuantity();
		shopkeeper.totalAmount=shopkeeper.getProductPrice()*shopkeeper.getProductQuantity();
	    shopkeeperrepo.save(shopkeeper);
	    //soapStock=shopkeeper.currentstock;
	    //shopkeeper.currentstock=0;
	  }
	else if(shopkeeper.getProductName().equalsIgnoreCase("Dabur") && pasteStock>shopkeeper.getProductQuantity())
	{
	    shopkeeper.currentStock=pasteStock-shopkeeper.getProductQuantity();
		shopkeeper.totalAmount=shopkeeper.getProductPrice()*shopkeeper.getProductQuantity();
	    shopkeeperrepo.save(shopkeeper);
	}
	else if(shopkeeper.getProductName().equalsIgnoreCase("Dark fantacy") && pasteStock>shopkeeper.getProductQuantity())
	{
	    shopkeeper.currentStock=biscutsStock-shopkeeper.getProductQuantity();
		shopkeeper.totalAmount=shopkeeper.getProductPrice()*shopkeeper.getProductQuantity();
	    shopkeeperrepo.save(shopkeeper);
	}
	else if(shopkeeper.getProductName().equalsIgnoreCase("Dairy milk") && pasteStock>shopkeeper.getProductQuantity())
	{
	    shopkeeper.currentStock=chocolateStock-shopkeeper.getProductQuantity();
		shopkeeper.totalAmount=shopkeeper.getProductPrice()*shopkeeper.getProductQuantity();
	    shopkeeperrepo.save(shopkeeper);
	}
	else if(shopkeeper.getProductName().equalsIgnoreCase("Maaza") && pasteStock>shopkeeper.getProductQuantity())
	{
	    shopkeeper.currentStock=coolDrinksStock-shopkeeper.getProductQuantity();
		shopkeeper.totalAmount=shopkeeper.getProductPrice()*shopkeeper.getProductQuantity();
	    shopkeeperrepo.save(shopkeeper);
	}
	
	
		return shopkeeper;
}

@Override
public List<Shopkeeper> fetchProductList() {
	// TODO Auto-generated method stub
	return shopkeeperrepo.findAll();
}

@Override
public Shopkeeper fetchProductById(Integer pid) throws ProductNotFoundException {
	// TODO Auto-generated method stub
	Optional<Shopkeeper> shopkeeper1= shopkeeperrepo.findById( pid);
	if(!shopkeeper1.isPresent())
	{
		throw new ProductNotFoundException("Product Id is not found");
	}
	return shopkeeperrepo.findById(pid).get();
}

@Override
public Shopkeeper updateProductById(Integer pid, Shopkeeper shopkeeper) throws ProductNotFoundException {
	
Optional<Shopkeeper> shopkeeper1= shopkeeperrepo.findById( pid);
Shopkeeper prodb=null;
			if(shopkeeper1.isPresent()) {
				prodb=	shopkeeperrepo.findById( pid).get();
				if(Objects.nonNull(shopkeeper.getProductName()) && !"".equalsIgnoreCase(shopkeeper.getProductName())) {
					prodb.setProductName(shopkeeper.getProductName());

				}
				if(Objects.nonNull(shopkeeper.getProductType()) && !"".equals(shopkeeper.getProductType())) {
					prodb.setProductType(shopkeeper.getProductType());
					System.out.println(shopkeeper.getProductType());
				}
				if(Objects.nonNull(shopkeeper.getProductBrand()) && !"".equals(shopkeeper.getProductBrand())) {
					prodb.setProductBrand(shopkeeper.getProductBrand());
					System.out.println(shopkeeper.getProductBrand());
				}
				if(Objects.nonNull(shopkeeper.getProductQuantity()) && !"".equals(shopkeeper.getProductQuantity())) {
					prodb.setProductQuantity(shopkeeper.getProductQuantity());
					System.out.println(shopkeeper.getProductQuantity());
				}
				if(Objects.nonNull(shopkeeper.getProductPrice()) && !"".equals(shopkeeper.getProductPrice())) {
					prodb.setProductPrice(shopkeeper.getProductPrice());
					System.out.println(shopkeeper.getProductPrice());
				}
			}
			else
			{
				throw new ProductNotFoundException("Product id not exists");
			}
				return shopkeeperrepo.save(prodb);

			
}

@Override
public void deleteProductById(Integer pid) throws ProductNotFoundException {
	// TODO Auto-generated method stub
	Optional<Shopkeeper> shopkeeper1= shopkeeperrepo.findById( pid);
	if(!shopkeeper1.isPresent())
	{
		throw new ProductNotFoundException("Product Id is not found");
	}
	shopkeeperrepo.deleteById(pid);
	
}

@Override
public Shopkeeper findByproductName(String pname) {
	// TODO Auto-generated method stub
	return shopkeeperrepo.findByproductName(pname);
}

@Override
public Shopkeeper findByproductType(String ptype) {
	// TODO Auto-generated method stub
	return shopkeeperrepo.findByProductType(ptype);
}

@Override
public Shopkeeper findByproductBrand(String pbrand) {
	// TODO Auto-generated method stub
	return shopkeeperrepo.findByProductBrand(pbrand);
}

@Override
public Shopkeeper findByproductQuantity(Integer pquantity) {
	// TODO Auto-generated method stub
	return shopkeeperrepo.findByProductQuantity(pquantity);
}

@Override
public Shopkeeper findByproductPrice(double pprice) {
	// TODO Auto-generated method stub
	return shopkeeperrepo.findByProductPrice(pprice);
}


}


















